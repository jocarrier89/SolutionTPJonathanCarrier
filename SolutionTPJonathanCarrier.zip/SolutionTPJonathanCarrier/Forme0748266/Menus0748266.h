//But: faire des d�clarations de fonctions pour les menus
//Auteur: Jonathan Carrier
//Date: Novembre 2020

#include <string>
#include <iostream>
using namespace std;

#pragma once
//Liste des d�clarations des fonctions qui permettent de g�rer les menus et leurs validation.

void afficherMenu1(); // Affiche le premier menu � l'utilisateur


void afficherMenu2(); // affiche le deuxi�me menu � l'utilisateur

	
int validerMenu(int choixMin, int choixMax); /// La fonction qui retourne le choix fait par l'utilisateur 

	
